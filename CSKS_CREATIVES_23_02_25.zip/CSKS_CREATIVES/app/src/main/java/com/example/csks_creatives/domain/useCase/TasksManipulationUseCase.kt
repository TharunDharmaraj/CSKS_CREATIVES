package com.example.csks_creatives.domain.useCase

import com.example.csks_creatives.domain.model.task.ClientTask
import com.example.csks_creatives.domain.model.utills.enums.TaskStatusType
import com.example.csks_creatives.domain.model.utills.sealed.ResultState
import com.example.csks_creatives.domain.repository.TasksManipulationRepository
import javax.inject.Inject

class TasksManipulationUseCase @Inject constructor(
    private val tasksManipulationRepository: TasksManipulationRepository
) : TasksManipulationUseCaseFactory {
    override fun create(): TasksManipulationUseCase {
        return TasksManipulationUseCase(tasksManipulationRepository)
    }

    override suspend fun assignTaskToEmployee(
        taskId: String,
        employeeId: String
    ): ResultState<String> {
        return try {
            tasksManipulationRepository.assignTaskToEmployee(taskId, employeeId)
            ResultState.Success("Task assigned successfully to employee $employeeId")
        } catch (exception: Exception) {
            ResultState.Error("Failed to assign task to employee ${exception.message}")
        }
    }

    override suspend fun changeTaskStatus(taskId: String, status: TaskStatusType): ResultState<String> {
        return try {
            tasksManipulationRepository.changeTaskStatus(taskId, status)
            ResultState.Success("Task status updated to ${status.name}")
        } catch (exception: Exception) {
            ResultState.Error("Failed to change task status ${exception.message}")
        }
    }

    override suspend fun editTask(task: ClientTask): ResultState<String> {
        return try {
            tasksManipulationRepository.editTask(task)
            ResultState.Success("Task '${task.taskName}' updated successfully")
        } catch (exception: Exception) {
            ResultState.Error("Failed to edit task ${exception.message}")
        }
    }
}