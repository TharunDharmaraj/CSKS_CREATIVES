package com.example.csks_creatives.domain.repository

import com.example.csks_creatives.domain.model.task.ClientTask
import kotlinx.coroutines.flow.Flow

interface TasksRepository {
    suspend fun createTask(task: ClientTask)

    fun getTasksForClient(clientId: String): Flow<List<ClientTask>>

    suspend fun getTasksForEmployee(employeeId: String): Flow<List<ClientTask>>

    suspend fun getActiveTasks(): Flow<List<ClientTask>>

    suspend fun getTasksInBackLog(): Flow<List<ClientTask>>
}