package com.example.csks_creatives.presentation.homeScreen.viewModel.commons

sealed class ToastUiEvent {
    data class ShowToast(val message: String) : ToastUiEvent()
}