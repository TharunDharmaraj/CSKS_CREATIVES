package com.example.csks_creatives.domain.model.utills.enums

// TODO once done with android impl, need to extend this to Destop
enum class Platform {
    ANDROID,
    DESKTOP
}