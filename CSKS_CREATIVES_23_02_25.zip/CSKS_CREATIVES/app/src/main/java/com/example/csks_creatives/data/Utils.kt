package com.example.csks_creatives.data

import com.example.csks_creatives.data.Constants.BACKLOG
import com.example.csks_creatives.data.Constants.COMPLETED
import com.example.csks_creatives.data.Constants.IN_PROGRESS
import com.example.csks_creatives.data.Constants.IN_REVIEW
import com.example.csks_creatives.data.Constants.REVISION_ONE
import com.example.csks_creatives.data.Constants.REVISION_THREE
import com.example.csks_creatives.data.Constants.REVISION_TWO
import com.example.csks_creatives.domain.model.utills.enums.TaskStatusType

object Utils {
    fun convertStringStatusToStatusType(status : String) : TaskStatusType {
        return when(status) {
            BACKLOG -> TaskStatusType.BACKLOG
            IN_PROGRESS -> TaskStatusType.IN_PROGRESS
            IN_REVIEW -> TaskStatusType.IN_REVIEW
            REVISION_ONE -> TaskStatusType.REVISION_ONE
            REVISION_TWO -> TaskStatusType.REVISION_TWO
            REVISION_THREE -> TaskStatusType.REVISION_THREE
            COMPLETED -> TaskStatusType.COMPLETED
            else -> TaskStatusType.BACKLOG
        }
    }

    fun convertStatusTypeToString(taskStatusType: TaskStatusType): String {
        return when (taskStatusType) {
            TaskStatusType.BACKLOG -> BACKLOG
            TaskStatusType.IN_PROGRESS -> IN_PROGRESS
            TaskStatusType.IN_REVIEW -> IN_REVIEW
            TaskStatusType.REVISION_ONE -> REVISION_ONE
            TaskStatusType.REVISION_TWO -> REVISION_TWO
            TaskStatusType.REVISION_THREE -> REVISION_THREE
            TaskStatusType.COMPLETED -> COMPLETED
        }
    }
}