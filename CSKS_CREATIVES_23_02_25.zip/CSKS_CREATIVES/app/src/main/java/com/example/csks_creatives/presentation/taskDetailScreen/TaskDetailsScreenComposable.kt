package com.example.csks_creatives.presentation.taskDetailScreen

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.csks_creatives.domain.model.utills.enums.TaskStatusType
import com.example.csks_creatives.domain.model.utills.sealed.UserRole
import com.example.csks_creatives.presentation.taskDetailScreen.components.DropdownMenuWithSelection
import com.example.csks_creatives.presentation.taskDetailScreen.viewModel.TaskDetailViewModel
import com.example.csks_creatives.presentation.taskDetailScreen.viewModel.event.TaskCommentsEvent
import com.example.csks_creatives.presentation.taskDetailScreen.viewModel.event.TaskDetailEvent

@Composable
fun TaskDetailsComposable(
    viewModel: TaskDetailViewModel = hiltViewModel(),
    userRole: UserRole = UserRole.Employee
) {
    val taskState = viewModel.taskDetailState.collectAsState()
    val commentState = viewModel.taskCommentState.collectAsState()
    val visibilityState = viewModel.visibilityState.collectAsState()
    val dropDownListState = viewModel.dropDownListState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Task Details", style = MaterialTheme.typography.bodyLarge)

        OutlinedTextField(
            value = taskState.value.taskTitle,
            onValueChange = {
                if (userRole == UserRole.Admin) viewModel.onEvent(
                    TaskDetailEvent.TaskTitleTextFieldChanged(
                        it
                    )
                )
            },
            label = { Text("Task Name") },
            readOnly = userRole != UserRole.Admin,
            modifier = Modifier.fillMaxWidth()
        )

        // Task Description
        OutlinedTextField(
            value = taskState.value.taskDescription,
            onValueChange = {
                if (userRole == UserRole.Admin) viewModel.onEvent(
                    TaskDetailEvent.TaskDescriptionTextFieldChanged(
                        it
                    )
                )
            },
            label = { Text("Task Description") },
            readOnly = userRole != UserRole.Admin,
            modifier = Modifier.fillMaxWidth()
        )

        // Assigned Employee (Dropdown)
        DropdownMenuWithSelection(
            label = "Assigned Employee",
            selectedItem = dropDownListState.value.employeeList.find { it.employeeId == taskState.value.taskAssignedTo }?.employeeName
                ?: "Select",
            items = dropDownListState.value.employeeList.map { it.employeeName },
            onItemSelected = { selectedEmployee ->
                val employee =
                    dropDownListState.value.employeeList.find { it.employeeName == selectedEmployee }
                employee?.let { viewModel.onEvent(TaskDetailEvent.TaskAssignedToEmployeeChanged(it.employeeId)) }
            },
            enabled = userRole == UserRole.Admin,
            isVisible = userRole != UserRole.Employee
        )

        // Assign Task to Client
        DropdownMenuWithSelection(
            label = "Assigned Task To Client",
            selectedItem = dropDownListState.value.clientsList.find { it.clientId == taskState.value.taskClientId }?.clientName
                ?: "Select",
            items = dropDownListState.value.clientsList.map { it.clientName },
            onItemSelected = { selectedClient ->
                val client =
                    dropDownListState.value.clientsList.find { it.clientName == selectedClient }
                client?.let { viewModel.onEvent(TaskDetailEvent.TaskClientIdChanged(it.clientId)) }
            },
            enabled = userRole == UserRole.Admin,
            isVisible = userRole != UserRole.Employee

        )

        // Story Points
        OutlinedTextField(
            value = taskState.value.taskStoryPoints.toString(),
            onValueChange = {
                if (userRole == UserRole.Admin) viewModel.onEvent(
                    TaskDetailEvent.TaskStoryPointsChanged(it.toDoubleOrNull() ?: 0.0)
                )
            },
            label = { Text("Story Points") },
            readOnly = userRole != UserRole.Admin,
            modifier = Modifier.fillMaxWidth()
        )

        // Task Status (Dropdown)
        DropdownMenuWithSelection(
            label = "Task Status",
            selectedItem = taskState.value.taskCurrentStatus.name,
            items = TaskStatusType.entries.map { it.name },
            onItemSelected = { selectedStatus ->
                viewModel.onEvent(
                    TaskDetailEvent.TaskStatusTypeChanged(
                        TaskStatusType.valueOf(
                            selectedStatus
                        )
                    )
                )
            },
        )

        // Mark as Completed Button
        Button(
            onClick = { viewModel.onEvent(TaskDetailEvent.TaskStatusTypeChanged(TaskStatusType.COMPLETED)) },
            modifier = Modifier.fillMaxWidth(),
            enabled = userRole == UserRole.Admin
        ) {
            Text("Mark as Completed")
        }

        // Toggle Comments Section
        Button(
            onClick = {
                viewModel.onEvent(TaskDetailEvent.ToggleCommentsSection)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (visibilityState.value.isCommentsSectionVisible) "Hide Comments" else "Show Comments")
        }

        if (visibilityState.value.isCommentsSectionVisible) {
            Column {
                taskState.value.taskComments.forEach { comment ->
                    Text(
                        "${comment.commentedBy}: ${comment.comment}",
                        modifier = Modifier.padding(4.dp)
                    )
                }

                OutlinedTextField(
                    value = commentState.value.commentString,
                    onValueChange = {
                        viewModel.onCommentEvent(TaskCommentsEvent.commentStringChanged(it))
                    },
                    label = { Text("Add a comment") },
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = { viewModel.onCommentEvent(TaskCommentsEvent.CreateComment) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Post Comment")
                }
            }
        }
        if (userRole == UserRole.Admin) {
            Button(
                onClick = { viewModel.onEvent(TaskDetailEvent.CreateTask) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Create Task")
            }
        } else {
            Button(
                onClick = { viewModel.onEvent(TaskDetailEvent.SaveTask) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Changes")
            }
        }
    }
}