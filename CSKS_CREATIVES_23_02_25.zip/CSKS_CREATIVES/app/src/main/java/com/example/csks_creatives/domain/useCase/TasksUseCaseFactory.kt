package com.example.csks_creatives.domain.useCase

import com.example.csks_creatives.domain.model.task.ClientTask
import com.example.csks_creatives.domain.model.utills.sealed.ResultState
import com.example.csks_creatives.presentation.homeScreen.viewModel.commons.DateOrder
import kotlinx.coroutines.flow.Flow

interface TasksUseCaseFactory {
    fun create(): TasksUseCase

    fun getTasksForClient(clientId: String): Flow<ResultState<List<ClientTask>>>

    fun getTasksForEmployee(
        employeeId: String,
        order: DateOrder
    ): Flow<ResultState<Pair<List<ClientTask>, List<ClientTask>>>>

    suspend fun createTask(task: ClientTask): ResultState<String>

    suspend fun getAllActiveTasks(): Flow<ResultState<List<ClientTask>>>

    suspend fun getAllBacklogTasks(): Flow<ResultState<List<ClientTask>>>
}