package com.example.csks_creatives.domain.useCase

import android.util.Log
import com.example.csks_creatives.domain.model.task.ClientTask
import com.example.csks_creatives.domain.model.utills.enums.TaskStatusType
import com.example.csks_creatives.domain.model.utills.sealed.ResultState
import com.example.csks_creatives.domain.repository.TasksRepository
import com.example.csks_creatives.domain.utils.Utils.getActiveTasks
import com.example.csks_creatives.domain.utils.Utils.getCompletedTasks
import com.example.csks_creatives.presentation.homeScreen.viewModel.commons.DateOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.util.UUID
import javax.inject.Inject


class TasksUseCase @Inject constructor(
    private val tasksRepository: TasksRepository
) : TasksUseCaseFactory {
    override fun create(): TasksUseCase {
        return TasksUseCase(tasksRepository)
    }

    override fun getTasksForClient(clientId: String): Flow<ResultState<List<ClientTask>>> = flow {
        emit(ResultState.Loading)
        try {
            tasksRepository.getTasksForClient(clientId)
                .collect { tasks ->
                    emit(ResultState.Success(tasks))
                }
        } catch (exception: Exception) {
            emit(ResultState.Error("Failed to fetch tasks for client ${exception.message}"))
        }
    }.flowOn(Dispatchers.IO)

    override fun getTasksForEmployee(
        employeeId: String,
        order: DateOrder
    ): Flow<ResultState<Pair<List<ClientTask>, List<ClientTask>>>> = flow {
        emit(ResultState.Loading)
        try {
            tasksRepository.getTasksForEmployee(employeeId)
                .collect { tasks ->
                    var activeTasks = tasks.getActiveTasks()
                    var completedTasks = tasks.getCompletedTasks()
                    when (order) {
                        DateOrder.Ascending -> {
                            activeTasks = activeTasks.sortedBy { it.taskCreationTime }
                            completedTasks = completedTasks.sortedBy { it.taskCreationTime }
                        }

                        DateOrder.Descending -> {
                            activeTasks = activeTasks.sortedByDescending { it.taskCreationTime }
                            completedTasks =
                                completedTasks.sortedByDescending { it.taskCreationTime }
                        }
                    }
                    emit(ResultState.Success(activeTasks to completedTasks))
                }
        } catch (exception: Exception) {
            emit(ResultState.Error("Failed to fetch tasks for employee ${exception.message}"))
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun createTask(task: ClientTask): ResultState<String> {
        return try {
            if (task.taskAttachment.isBlank()) ResultState.Error("Task Description Cannot Be Empty")
            if (task.taskName.isBlank()) ResultState.Error("Task Name Cannot Be Empty")
            if (task.clientId.isBlank()) ResultState.Error("Task Client Cannot be Empty")
            val taskToCreate = task.copy(
                taskId = "asknbdkasbds",
                taskCreationTime = System.currentTimeMillis().toString(),
                currentStatus = TaskStatusType.BACKLOG,
                statusHistory = emptyList(),
                comments = emptyList()
            )
            tasksRepository.createTask(taskToCreate)
            ResultState.Success("~~Comment Posted Successfully")
        } catch (exception: Exception) {
            ResultState.Error("Failed to create task ${exception.message}")
        }
    }

    override suspend fun getAllActiveTasks(): Flow<ResultState<List<ClientTask>>> = flow {
        emit(ResultState.Loading)
        try {
            tasksRepository.getActiveTasks().collect { tasks ->
                Log.d("tharun", "Tasks in UC $tasks")
                emit(ResultState.Success(tasks))
            }
        } catch (exception: Exception) {
            emit(ResultState.Error("Failed to get All active Tasks"))
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun getAllBacklogTasks(): Flow<ResultState<List<ClientTask>>> = flow {
        emit(ResultState.Loading)
        try {
            tasksRepository.getTasksInBackLog().collect { tasks ->
                emit(ResultState.Success(tasks))
            }
        } catch (exception: Exception) {
            emit(ResultState.Error("Failed to get All Backlog Tasks"))
        }
    }.flowOn(Dispatchers.IO)
}