package com.example.csks_creatives.presentation.homeScreen.viewModel.commons

sealed class DateOrder {
    object Ascending : DateOrder()
    object Descending : DateOrder()
}