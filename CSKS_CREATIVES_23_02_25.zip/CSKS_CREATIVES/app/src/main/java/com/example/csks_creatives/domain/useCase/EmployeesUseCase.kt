package com.example.csks_creatives.domain.useCase

import com.example.csks_creatives.domain.repository.EmployeeRepository
import javax.inject.Inject

class EmployeesUseCase @Inject constructor(
    private val employeeRepository: EmployeeRepository
) : EmployeesUseCaseFactory {
    override fun create(): EmployeesUseCase {
        return EmployeesUseCase(employeeRepository = employeeRepository)
    }
}