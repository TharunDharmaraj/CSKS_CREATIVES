package com.example.csks_creatives.domain.useCase

interface EmployeesUseCaseFactory {
    fun create(): EmployeesUseCase
}