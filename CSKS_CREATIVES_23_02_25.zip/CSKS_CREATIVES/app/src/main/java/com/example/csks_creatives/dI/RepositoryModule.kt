package com.example.csks_creatives.dI

import com.example.csks_creatives.data.repositoryImplementation.AdminRepositoryImplementation
import com.example.csks_creatives.data.repositoryImplementation.ClientsRepositoryImplementation
import com.example.csks_creatives.data.repositoryImplementation.CommentsRepositoryImplementation
import com.example.csks_creatives.data.repositoryImplementation.LoginRepositoryImplementation
import com.example.csks_creatives.data.repositoryImplementation.TasksManipulationRepositoryImplementation
import com.example.csks_creatives.data.repositoryImplementation.TasksRepositoryImplementation
import com.example.csks_creatives.domain.repository.AdminRepository
import com.example.csks_creatives.domain.repository.ClientsRepository
import com.example.csks_creatives.domain.repository.CommentsRepository
import com.example.csks_creatives.domain.repository.LoginRepository
import com.example.csks_creatives.domain.repository.TasksManipulationRepository
import com.example.csks_creatives.domain.repository.TasksRepository
import com.google.firebase.firestore.FirebaseFirestore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideAdminRepository(firestore: FirebaseFirestore): AdminRepository {
        return AdminRepositoryImplementation(firestore)
    }

    @Provides
    @Singleton
    fun provideClientsRepository(firestore: FirebaseFirestore): ClientsRepository {
        return ClientsRepositoryImplementation(firestore)
    }

    @Provides
    @Singleton
    fun provideCommentsRepository(firestore: FirebaseFirestore): CommentsRepository {
        return CommentsRepositoryImplementation(firestore)
    }

    @Provides
    @Singleton
    fun provideTasksRepository(firestore: FirebaseFirestore): TasksRepository {
        return TasksRepositoryImplementation(firestore)
    }

    @Provides
    @Singleton
    fun provideTasksManipulationRepository(firestore: FirebaseFirestore): TasksManipulationRepository {
        return TasksManipulationRepositoryImplementation(firestore)
    }

    @Provides
    @Singleton
    fun provideLoginRepository(firestore: FirebaseFirestore): LoginRepository {
        return LoginRepositoryImplementation(firestore)
    }
}
