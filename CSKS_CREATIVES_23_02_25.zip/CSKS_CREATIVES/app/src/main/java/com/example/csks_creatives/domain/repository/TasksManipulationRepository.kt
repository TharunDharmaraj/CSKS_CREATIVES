package com.example.csks_creatives.domain.repository

import com.example.csks_creatives.domain.model.utills.enums.TaskStatusType
import com.example.csks_creatives.domain.model.task.ClientTask

interface TasksManipulationRepository {
    suspend fun assignTaskToEmployee(taskId: String, employeeId: String)

    suspend fun changeTaskStatus(taskId: String, status: TaskStatusType)

    suspend fun editTask(task: ClientTask)
}