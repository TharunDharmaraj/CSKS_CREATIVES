package com.example.csks_creatives.domain.repository

interface EmployeeRepository {
}