package com.example.csks_creatives.domain.model.task

import com.example.csks_creatives.data.Constants.TASK_STATUS_HISTORY_END_TIME
import com.example.csks_creatives.data.Constants.TASK_STATUS_HISTORY_START_TIME
import com.example.csks_creatives.domain.model.utills.enums.TaskStatusType
import com.example.csks_creatives.domain.utils.Utils.EMPTY_STRING
import com.google.firebase.firestore.PropertyName

data class TaskStatusHistory(
    val taskStatusType: TaskStatusType = TaskStatusType.BACKLOG,
    @PropertyName(TASK_STATUS_HISTORY_START_TIME) val startTime: String = EMPTY_STRING,
    @PropertyName(TASK_STATUS_HISTORY_END_TIME) val endTime: String = EMPTY_STRING,
)