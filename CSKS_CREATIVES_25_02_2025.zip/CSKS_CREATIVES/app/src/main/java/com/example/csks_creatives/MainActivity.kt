package com.example.csks_creatives

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.csks_creatives.presentation.clientTasksListScreen.ClientTasksListComposable
import com.example.csks_creatives.ui.theme.CSKS_CREATIVESTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CSKS_CREATIVESTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
//                    LoginScreen()
//                    HomeScreenComposable(
//                        horizontalAlignment = Alignment.CenterHorizontally,
//                        verticalArrangement = Arrangement.Center
//                    )
//                    TaskDetailsComposable()
                    ClientTasksListComposable()
//                    TasksRepositoryImplementation(FirebaseFirestore.getInstance()).generateAndCreateTasks(
//                        10
//                    )
//                    ClientsRepositoryImplementation(FirebaseFirestore.getInstance()).createMockClients(
//                        10
//                    )
//                    AdminRepositoryImplementation(FirebaseFirestore.getInstance()).createEmployees(6)
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    CSKS_CREATIVESTheme {
        Greeting("Android")
    }
}