package com.example.csks_creatives.presentation.clientTasksListScreen.viewModel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.csks_creatives.domain.model.task.ClientTask
import com.example.csks_creatives.domain.model.utills.sealed.ResultState
import com.example.csks_creatives.domain.useCase.TasksUseCaseFactory
import com.example.csks_creatives.presentation.clientTasksListScreen.viewModel.event.ClientTasksListScreenEvent
import com.example.csks_creatives.presentation.clientTasksListScreen.viewModel.state.ClientTasksListState
import com.example.csks_creatives.presentation.components.DateOrder
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ClientTasksListViewModel @Inject constructor(
    private val tasksUseCaseFactory: TasksUseCaseFactory
) : ViewModel() {
    init {
        tasksUseCaseFactory.create()
        getClientTasks(DateOrder.Descending, "1")
    }

    private val _allTasksForClientFromFireStore = MutableStateFlow<List<ClientTask>>(emptyList())

    private val _clientTasksListState = MutableStateFlow(ClientTasksListState())
    val clientsTasksListState = _clientTasksListState.asStateFlow()

    fun onEvent(clientTaskListScreenEvent: ClientTasksListScreenEvent) {
        when (clientTaskListScreenEvent) {
            ClientTasksListScreenEvent.OnClientTaskClicked -> {
                // TODO Navigate
            }

            is ClientTasksListScreenEvent.OnSearchTextChanged -> {
                _clientTasksListState.value = _clientTasksListState.value.copy(
                    searchText = clientTaskListScreenEvent.searchText
                )
                filterTasks()
            }

            is ClientTasksListScreenEvent.Order -> {
                val newOrder = clientTaskListScreenEvent.order
                _clientTasksListState.value =
                    _clientTasksListState.value.copy(tasksOrder = newOrder)
                sortTasks(newOrder)
            }

            is ClientTasksListScreenEvent.ToggleStatusFilter -> {
                val currentSet = _clientTasksListState.value.selectedStatuses.toMutableSet()
                if (currentSet.contains(clientTaskListScreenEvent.status)) {
                    currentSet.remove(clientTaskListScreenEvent.status)
                } else {
                    currentSet.add(clientTaskListScreenEvent.status)
                }
                _clientTasksListState.value =
                    _clientTasksListState.value.copy(selectedStatuses = currentSet)
                filterTasks()
            }
        }
    }

    private fun getClientTasks(order: DateOrder, clientId: String) {
        viewModelScope.launch {
            tasksUseCaseFactory.getTasksForClient(order, clientId).collect { result ->
                if (result is ResultState.Success) {
                    val clientTasksList = result.data
                    _allTasksForClientFromFireStore.value = clientTasksList
                    _clientTasksListState.value = _clientTasksListState.value.copy(
                        tasksList = clientTasksList
                    )
                    filterTasks()
                }
            }
        }
    }

    private fun filterTasks() {
        val searchText = _clientTasksListState.value.searchText.lowercase()
        val selectedStatuses = _clientTasksListState.value.selectedStatuses

        var filteredList = _allTasksForClientFromFireStore.value

        if (searchText.isNotBlank()) {
            filteredList = filteredList.filter { task ->
                task.taskName.lowercase().contains(searchText) ||
                        task.currentStatus.name.lowercase().contains(searchText) ||
                        task.taskAttachment.lowercase().contains(searchText)
            }
        }

        if (selectedStatuses.isNotEmpty()) {
            filteredList = filteredList.filter { task -> task.currentStatus in selectedStatuses }
        }

        _clientTasksListState.value = _clientTasksListState.value.copy(tasksList = filteredList)
    }

    private fun sortTasks(order: DateOrder) {
        val sortedList = if (order is DateOrder.Ascending) {
            _clientTasksListState.value.tasksList.sortedBy { it.taskCreationTime }
        } else {
            _clientTasksListState.value.tasksList.sortedByDescending { it.taskCreationTime }
        }

        _clientTasksListState.value = _clientTasksListState.value.copy(tasksList = sortedList)
    }
}