package com.example.csks_creatives.data.repositoryImplementation

import android.util.Log
import com.example.csks_creatives.data.Constants.EMPLOYEES_COUNT
import com.example.csks_creatives.data.Constants.EMPLOYEES_COUNT_FIELD
import com.example.csks_creatives.data.Constants.EMPLOYEE_COLLECTION
import com.example.csks_creatives.data.Constants.EMPLOYEE_COUNT_DEFAULT
import com.example.csks_creatives.data.Constants.EMPLOYEE_EMPLOYEE_ID
import com.example.csks_creatives.data.Constants.EMPLOYEE_EMPLOYEE_JOINED_TIME
import com.example.csks_creatives.data.Constants.EMPLOYEE_EMPLOYEE_NAME
import com.example.csks_creatives.data.Constants.EMPLOYEE_EMPLOYEE_NUMBER_OF_TASKS_COMPLETED
import com.example.csks_creatives.data.Constants.EMPLOYEE_EMPLOYEE_PASSWORD
import com.example.csks_creatives.data.Constants.EMPLOYEE_EMPLOYEE_TASKS_COMPLETED
import com.example.csks_creatives.data.Constants.EMPLOYEE_EMPLOYEE_TASKS_IN_PROGRESS
import com.example.csks_creatives.domain.model.employee.Employee
import com.example.csks_creatives.domain.repository.AdminRepository
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.toObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AdminRepositoryImplementation @Inject constructor(
    private val firestore: FirebaseFirestore
) : AdminRepository {
    private val logTag = "AdminRepository"
    private val adminRepoCoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override suspend fun createEmployee(employee: Employee) {
        val employeeId = employee.employeeId
        try {
            getEmployeePathForId(employeeId).set(
                hashMapOf(
                    EMPLOYEE_EMPLOYEE_ID to employeeId,
                    EMPLOYEE_EMPLOYEE_NAME to employee.employeeName,
                    EMPLOYEE_EMPLOYEE_JOINED_TIME to employee.joinedTime,
                    EMPLOYEE_EMPLOYEE_PASSWORD to employee.employeePassword,
                    EMPLOYEE_EMPLOYEE_TASKS_COMPLETED to employee.tasksCompleted,
                    EMPLOYEE_EMPLOYEE_TASKS_IN_PROGRESS to employee.tasksInProgress,
                    EMPLOYEE_EMPLOYEE_NUMBER_OF_TASKS_COMPLETED to employee.numberOfTasksCompleted
                ),
                SetOptions.merge()
            ).await()
            Log.d(
                logTag + "Create",
                "Successfully Created Employee on Firestore Employee : $employee"
            )
            adminRepoCoroutineScope.launch {
                incrementEmployeeCount()
            }
        } catch (error: Exception) {
            Log.d(logTag + "Create", "Failure $error Creation Employee : $employee")
        }
    }

    override suspend fun deleteEmployee(employeeId: String) {
        try {
            getEmployeePathForId(employeeId).delete().await()
            Log.d(
                logTag + "Delete",
                "Successfully Deleted Employee on Firestore EmployeeId $employeeId"
            )
            adminRepoCoroutineScope.launch {
                decrementEmployeeCount()
            }
        } catch (error: Exception) {
            Log.d(logTag + "Delete", "Failure $error in Deletion EmployeeId $employeeId")
        }
    }

    override suspend fun getEmployeeDetails(employeeId: String): Employee {
        return try {
            val employeeDocument = getEmployeePathForId(employeeId).get().await()
            if (employeeDocument.exists()) {
                val employeeDetails = employeeDocument.toObject<Employee>()
                Log.d(
                    logTag + "GetDetails",
                    "Employee Details for employeeId Exists $employeeDetails"
                )
                employeeDetails ?: Employee()
            } else {
                Log.d(
                    logTag + "GetDetails",
                    "Employee Details for employeeId $employeeId Not Exists"
                )
                Employee()
            }
        } catch (error: Exception) {
            Log.d(logTag + "GetDetails", "Error fetching Employee Details: $error")
            Employee()
        }
    }

    override suspend fun getEmployees(): List<Employee> {
        return try {
            val snapshot = firestore.collection(EMPLOYEE_COLLECTION).get().await()
            Log.d(
                logTag + "Get",
                "Successfully fetched Employees list size: ${snapshot.documents.size}"
            )
            return snapshot.documents.mapNotNull { it.toObject(Employee::class.java) }
        } catch (exception: Exception) {
            Log.d(logTag + "Get", "Error $exception in fetching Employees")
            emptyList()
        }
    }

    override suspend fun getEmployeeCount(): Int {
        return try {
            val employeeCountDocument = getPathForEmployeeCount().get().await()
            if (employeeCountDocument.exists()) {
                employeeCountDocument.getLong(EMPLOYEES_COUNT)?.toInt() ?: EMPLOYEE_COUNT_DEFAULT
            } else {
                EMPLOYEE_COUNT_DEFAULT
            }
        } catch (error: Exception) {
            Log.d(logTag + "GetCount", "Error fetching Employee Count: $error")
            EMPLOYEE_COUNT_DEFAULT
        }
    }

    override suspend fun checkEmployeeIdExists(employeeId: String): Boolean {
        try {
            val employeePath = getEmployeePathForId(employeeId).get().await()
            if (employeePath.exists()) {
                Log.d(logTag + "check", "EmployeeId already found: $employeeId")
                return true
            }
            Log.d(logTag + "check", "EmployeeId not found: $employeeId")
            return false
        } catch (exception: Exception) {
            Log.d(logTag + "check", "Error fetching Employee exists: $employeeId")
            return true
        }
    }

    private fun getEmployeePathForId(employeeId: String) =
        firestore.collection(EMPLOYEE_COLLECTION).document(employeeId)

    private fun getPathForEmployeeCount() =
        firestore.collection(EMPLOYEE_COLLECTION).document(EMPLOYEES_COUNT)

    private suspend fun incrementEmployeeCount() {
        try {
            val employeeCountDocument = getPathForEmployeeCount().get().await()
            val employeeCount =
                (employeeCountDocument.getLong(EMPLOYEES_COUNT_FIELD) ?: EMPLOYEE_COUNT_DEFAULT)

            getPathForEmployeeCount().set(
                hashMapOf(EMPLOYEES_COUNT_FIELD to employeeCount.toInt() + 1),
                SetOptions.merge()
            ).await()

            Log.d(logTag + "AddCount", "Successfully Updated Employee Count")
        } catch (error: Exception) {
            Log.d(logTag + "AddCount", "Failure $error On Updating Employee Count")
        }
    }

    private suspend fun decrementEmployeeCount() {
        try {
            val employeeCountDocument = getPathForEmployeeCount().get().await()
            val employeeCount =
                (employeeCountDocument.getLong(EMPLOYEES_COUNT_FIELD) ?: EMPLOYEE_COUNT_DEFAULT)

            getPathForEmployeeCount().set(
                hashMapOf(EMPLOYEES_COUNT_FIELD to employeeCount.toInt() - 1),
                SetOptions.merge()
            ).await()

            Log.d(logTag + "RemoveCount", "Successfully Updated Employee Count")
        } catch (error: Exception) {
            Log.d(logTag + "RemoveCount", "Failure $error On Updating Employee Count")
        }
    }

    // Create Employees
    fun createEmployees(number: Int) {
        val db = firestore.collection(EMPLOYEE_COLLECTION)
        repeat(number) {
            val hash = hashMapOf(
                EMPLOYEE_EMPLOYEE_ID to UUID.randomUUID().toString(),
                EMPLOYEE_EMPLOYEE_NAME to "Employee ${it + 10}",
                EMPLOYEE_EMPLOYEE_JOINED_TIME to System.currentTimeMillis().toString(),
                EMPLOYEE_EMPLOYEE_PASSWORD to "Employee Password ${it + 10}",
            )
            db.document("Employee ${it + 10}").set(hash)
        }
    }
}