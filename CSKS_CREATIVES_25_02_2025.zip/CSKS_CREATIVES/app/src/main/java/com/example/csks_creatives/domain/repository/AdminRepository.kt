package com.example.csks_creatives.domain.repository

import com.example.csks_creatives.domain.model.employee.Employee

interface AdminRepository {
    suspend fun createEmployee(employee: Employee)

    suspend fun deleteEmployee(employeeId: String)

    suspend fun getEmployeeDetails(employeeId: String): Employee

    suspend fun getEmployees(): List<Employee>

    suspend fun getEmployeeCount(): Int

    suspend fun checkEmployeeIdExists(employeeId: String): Boolean
}