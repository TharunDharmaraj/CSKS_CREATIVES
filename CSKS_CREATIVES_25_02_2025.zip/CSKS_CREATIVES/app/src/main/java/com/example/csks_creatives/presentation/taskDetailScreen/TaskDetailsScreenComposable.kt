package com.example.csks_creatives.presentation.taskDetailScreen

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.csks_creatives.domain.model.utills.sealed.UserRole
import com.example.csks_creatives.presentation.taskDetailScreen.components.TaskDetailComposable
import com.example.csks_creatives.presentation.taskDetailScreen.viewModel.TaskDetailViewModel

@Composable
fun TaskDetailsComposable(
    viewModel: TaskDetailViewModel = hiltViewModel(),
    userRole: UserRole = UserRole.Admin,
    isTaskCreation: Boolean = true,
    taskId: String = "asknbdkasbds+${System.currentTimeMillis().toString().takeLast(2)}"
) {
    LaunchedEffect(taskId) {
        if (userRole == UserRole.Employee || (userRole == UserRole.Admin && isTaskCreation.not())) {
            viewModel.fetchTaskDetails(taskId)
            viewModel.fetchCommentsForTask(taskId)
        }
    }
    TaskDetailComposable(viewModel, isTaskCreation, userRole, taskId)
}