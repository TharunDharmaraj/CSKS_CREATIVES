package com.example.csks_creatives.dI

import com.example.csks_creatives.domain.repository.AdminRepository
import com.example.csks_creatives.domain.repository.ClientsRepository
import com.example.csks_creatives.domain.repository.CommentsRepository
import com.example.csks_creatives.domain.repository.LoginRepository
import com.example.csks_creatives.domain.repository.TasksManipulationRepository
import com.example.csks_creatives.domain.repository.TasksRepository
import com.example.csks_creatives.domain.useCase.AdminUseCase
import com.example.csks_creatives.domain.useCase.AdminUseCaseFactory
import com.example.csks_creatives.domain.useCase.ClientsUseCase
import com.example.csks_creatives.domain.useCase.ClientsUseCaseFactory
import com.example.csks_creatives.domain.useCase.CommentsUseCase
import com.example.csks_creatives.domain.useCase.CommentsUseCaseFactory
import com.example.csks_creatives.domain.useCase.TasksManipulationUseCase
import com.example.csks_creatives.domain.useCase.TasksManipulationUseCaseFactory
import com.example.csks_creatives.domain.useCase.TasksUseCase
import com.example.csks_creatives.domain.useCase.TasksUseCaseFactory
import com.example.csks_creatives.domain.useCase.UserLoginUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {
    @Provides
    fun provideAdminUseCaseFactory(adminRepository: AdminRepository): AdminUseCaseFactory {
        return AdminUseCase(adminRepository)
    }

    @Provides
    fun provideClientsUseCaseFactory(clientsRepository: ClientsRepository): ClientsUseCaseFactory {
        return ClientsUseCase(clientsRepository)
    }

    @Provides
    fun provideCommentsUseCaseFactory(commentsRepository: CommentsRepository): CommentsUseCaseFactory {
        return CommentsUseCase(commentsRepository)
    }

    @Provides
    fun provideTasksManipulationsUseCaseFactory(
        tasksManipulationRepository: TasksManipulationRepository,
        adminRepository: AdminRepository
    ): TasksManipulationUseCaseFactory {
        return TasksManipulationUseCase(tasksManipulationRepository, adminRepository)
    }

    @Provides
    fun provideTasksUseCaseFactory(
        tasksRepository: TasksRepository,
        adminRepository: AdminRepository
    ): TasksUseCaseFactory {
        return TasksUseCase(tasksRepository, adminRepository)
    }

    @Provides
    fun provideUserLoginUseCase(loginRepository: LoginRepository): UserLoginUseCase {
        return UserLoginUseCase(loginRepository)
    }
}