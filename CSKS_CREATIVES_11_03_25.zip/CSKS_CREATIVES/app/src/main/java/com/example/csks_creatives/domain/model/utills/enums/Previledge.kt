package com.example.csks_creatives.domain.model.utills.enums

enum class Previledge {
    ADMIN,
    EMPLOYEE
}